#!/bin/sh

jslint epc-deck.js epc-graph.js epc-table.js epc-test.js epc-ui.js epc-code.js
